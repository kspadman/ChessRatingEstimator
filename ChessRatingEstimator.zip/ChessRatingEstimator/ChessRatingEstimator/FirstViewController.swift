//
//  FirstViewController.swift
//  tabbedEstimator
//
//  Created by Karthik Padmanabhan on 3/30/20.
//  Copyright © 2020 Karthik Padmanabhan. All rights reserved.
//

import UIKit
import Foundation
import Darwin

class FirstViewController: UIViewController, UITextFieldDelegate {
   
     @IBOutlet weak var mainView: UIView!
     
     @IBOutlet weak var newRatingLabel: UILabel!
     @IBOutlet weak var totalPoints: UITextField!
     @IBOutlet weak var preRating: UITextField!
     @IBOutlet weak var performanceLabel: UILabel!
     @IBOutlet weak var priorGames: UITextField!
     
     @IBOutlet weak var gameOne: UITextField!
     @IBOutlet weak var gameTwo: UITextField!
     @IBOutlet weak var gameThree: UITextField!
     @IBOutlet weak var gameFour: UITextField!
     @IBOutlet weak var gameFive: UITextField!
     @IBOutlet weak var gameSix: UITextField!
     @IBOutlet weak var gameSeven: UITextField!
     @IBOutlet weak var gameEight: UITextField!
     @IBOutlet weak var gameNine: UITextField!
     
     var isGameOne = false
     var isGameTwo = false
     var isGameThree = false
     var isGameFour = false
     var isGameFive = false
     var isGameSix = false
     var isGameSeven = false
     var isGameEight = false
     var isGameNine = false
     
     func collectDouble (game: UITextField) -> Double {
         let numberFormatter = NumberFormatter()
         guard let rating = numberFormatter.number(from: game.text!)?.doubleValue else {
             print ("invalid rating")
             return 0
         }
         print (rating)
         return rating
     }
     
     @IBAction func performanceRating(_ sender: Any) {
         
         let opp1 = collectDouble(game: gameOne)
         let opp2 = collectDouble(game: gameTwo)
         let opp3 = collectDouble(game: gameThree)
         let opp4 = collectDouble(game: gameFour)
         let opp5 = collectDouble(game: gameFive)
         let opp6 = collectDouble(game: gameSix)
         let opp7 = collectDouble(game: gameSeven)
         let opp8 = collectDouble(game: gameEight)
         let opp9 = collectDouble(game: gameNine)
        
        var gamesArray: [Double] = [opp1, opp2, opp3, opp4, opp5, opp6, opp7, opp8, opp9]
        let zero = [0.0]
        gamesArray.removeAll(where: {zero.contains($0)})
    
        print(gamesArray)
        
        var highestOpp: Double = 0.0
        var lowestOpp: Double = 0.0
        
        if (gamesArray.count > 0) {
            highestOpp = gamesArray.max()!
            lowestOpp = gamesArray.min()!
        }
         let totalP = collectDouble(game: totalPoints)
         
        if (opp1 > 0) { isGameOne = true } else { isGameOne = false }
        if (opp2 > 0) { isGameTwo = true } else { isGameTwo = false }
        if (opp3 > 0) { isGameThree = true } else { isGameThree = false }
        if (opp4 > 0) { isGameFour = true } else { isGameFour = false }
        if (opp5 > 0) { isGameFive = true } else { isGameFive = false }
        if (opp6 > 0) { isGameSix = true } else { isGameSix = false }
        if (opp7 > 0) { isGameSeven = true } else { isGameSeven = false }
        if (opp8 > 0) { isGameEight = true } else { isGameEight = false }
        if (opp9 > 0) { isGameNine = true } else { isGameNine = false }
         
         var numberGames = 0.0
         if (isGameOne) { numberGames = numberGames + 1  }
         if (isGameTwo) { numberGames = numberGames + 1  }
         if (isGameThree) { numberGames = numberGames + 1 }
         if (isGameFour) { numberGames = numberGames + 1  }
         if (isGameFive) { numberGames = numberGames + 1  }
         if (isGameSix) { numberGames = numberGames + 1  }
         if (isGameSeven) { numberGames = numberGames + 1  }
         if (isGameEight) { numberGames = numberGames + 1  }
         if (isGameNine) { numberGames = numberGames + 1  }
         
         print (numberGames)
         
         let averageRating = (opp1+opp2+opp3+opp4+opp5+opp6+opp7+opp8+opp9)/numberGames
         print(averageRating)
        
        var performance: Double = 0.0
        var myExp=0.0, pvEst = 0.0, myEst=4000.0, myLow=0.0, myHigh=4000.0, fDiff=0.0
        let log10 = log(Double(10));
        let e = Darwin.M_E
        
        while (abs(myEst - pvEst) > 0.1) {
            
            myExp = 0.0
            
            for n in gamesArray
            {
                myExp = myExp + (1.0/((pow(e, (log10*((n-myEst)/400.0))))+1.0))
                print("myEXP: ", myExp)
            }
        
            print("my Exp: ", myExp)
        
            fDiff = myExp - totalP
            pvEst = myEst
            if ( fDiff > 0.0 )
            {
                myHigh = myEst
                myEst = ( myEst + myLow ) / 2.0
            }
            else
            {
                myLow = myEst
                myEst = ( myEst + myHigh ) / 2.0
            }
        }
        performance = Double(round(myEst))
        print (performance)
        
    
        var percentage: Double = (totalP/numberGames)*100
        percentage = Double(round(percentage)/100)
        let percent: Int = Int(percentage*100)
        print(percent)
        /*
        if (percent>100) {
            performanceLabel.text = "Invalid"
            return
        }
        var pointsArray = [Int]()
        for n in 0...100 {
            pointsArray.append(n)
        }
        
        let dpArray: [Double] = [-800,-677,-589,-538,-501,-470,-444,-422,-401,-383,-366,-351,-336,-322,-309,-296,-284,-273,-262,-251,-240,-230,-220,-211,-202,-193,-184,-175,-166,-158,-149,-141,-133,-125,-117,-110,-102,-95,-87,-80,-72,-65,-57,-50,-43,-36,-29,-21,-14,-7,0,7,14,21,29,36,43,50,57,65,72,80,87,95,102,110,117,125,133,141,149,158,166,175,184,193,202,211,220,230,240,251,262,273,284,296,309,322,336,351,366,383,401,422,444,470,501,538,589,677,800]
                
        let performanceDict = Dictionary(uniqueKeysWithValues: zip(pointsArray, dpArray))
        var performance = Int(averageRating + (performanceDict [percent]!))
        */
        
        if (percent == 100) { performance = (highestOpp + 400)}
        if (percent == 0) { performance = (lowestOpp - 400)}
        
 
        if (totalP > numberGames)
        { performanceLabel.text = "Invalid"
            newRatingLabel.text = "Invalid"
            
        }
        
      //  else if ((opp1>3100) || (opp2>3100) || (opp3>3100) || (opp4>3100) || (opp5>3100) || (opp6>3100) || (opp7>3100) || (opp8>3100) || (opp9>3100))
   //     { newRatingLabel.text = "Invalid"
 //           performanceLabel.text = "Invalid" }
        
        else { performanceLabel.text = String(format: "%0.0f", performance) }
         
         
     }
     
     @IBAction func newRating(_ sender: Any) {
         
         var numPrevious = collectDouble(game: priorGames)
         if (numPrevious > 50.0) { numPrevious = 50.0 }
    
         var totalE: Double
         var bonus: Double = 0.0
        var myBonusGameCount: Double
         
         let opp1 = collectDouble(game: gameOne)
         let opp2 = collectDouble(game: gameTwo)
         let opp3 = collectDouble(game: gameThree)
         let opp4 = collectDouble(game: gameFour)
         let opp5 = collectDouble(game: gameFive)
         let opp6 = collectDouble(game: gameSix)
         let opp7 = collectDouble(game: gameSeven)
         let opp8 = collectDouble(game: gameEight)
         let opp9 = collectDouble(game: gameNine)
         
         let pre = collectDouble(game: preRating)
         let totalP = collectDouble(game: totalPoints)
        
        var gamesArray: [Double] = [opp1, opp2, opp3, opp4, opp5, opp6, opp7, opp8, opp9]
        let zero = [0.0]
        gamesArray.removeAll(where: {zero.contains($0)})
         
         print(opp1, opp2, opp3, opp4, opp5, opp6, opp7, opp8, opp9)
         
         if (opp1 > 0) { isGameOne = true } else { isGameOne = false }
         if (opp2 > 0) { isGameTwo = true } else { isGameTwo = false }
         if (opp3 > 0) { isGameThree = true } else { isGameThree = false }
         if (opp4 > 0) { isGameFour = true } else { isGameFour = false }
         if (opp5 > 0) { isGameFive = true } else { isGameFive = false }
         if (opp6 > 0) { isGameSix = true } else { isGameSix = false }
         if (opp7 > 0) { isGameSeven = true } else { isGameSeven = false }
         if (opp8 > 0) { isGameEight = true } else { isGameEight = false }
         if (opp9 > 0) { isGameNine = true } else { isGameNine = false }
         
         print(isGameOne)
         print(isGameTwo)
         print(isGameThree)
         print(isGameFour)
         print(isGameFive)
         print(isGameSix)
         print(isGameSeven)
         print(isGameEight)
         print(isGameNine)
         
         var numGames = 0.0
         if (isGameOne) { numGames = numGames + 1  }
         if (isGameTwo) { numGames = numGames + 1  }
         if (isGameThree) { numGames = numGames + 1 }
         if (isGameFour) { numGames = numGames + 1  }
         if (isGameFive) { numGames = numGames + 1  }
         if (isGameSix) { numGames = numGames + 1  }
         if (isGameSeven) { numGames = numGames + 1  }
         if (isGameEight) { numGames = numGames + 1  }
         if (isGameNine) { numGames = numGames + 1  }
         
         let nR: Double
         let power: Double = pow((2569-pre), 2)
         let num: Double = 0.662 + (0.00000739 * power)
         
         nR = 50 / (num.squareRoot())
         if (nR < numPrevious) { numPrevious = nR }
         
        let K: Double = 800.0 / (numPrevious + numGames)
         
         let E1 = calculateE(preRating: pre, opponent: opp1)
         let E2 = calculateE(preRating: pre, opponent: opp2)
         let E3 = calculateE(preRating: pre, opponent: opp3)
         let E4 = calculateE(preRating: pre, opponent: opp4)
         let E5 = calculateE(preRating: pre, opponent: opp5)
         let E6 = calculateE(preRating: pre, opponent: opp6)
         let E7 = calculateE(preRating: pre, opponent: opp7)
         let E8 = calculateE(preRating: pre, opponent: opp8)
         let E9 = calculateE(preRating: pre, opponent: opp9)

         totalE = 0.0
         if (isGameOne) { totalE = totalE + E1 }
         if (isGameTwo) { totalE = totalE + E2 }
         if (isGameThree) { totalE = totalE + E3 }
         if (isGameFour) { totalE = totalE + E4 }
         if (isGameFive) { totalE = totalE + E5 }
         if (isGameSix) { totalE = totalE + E6 }
         if (isGameSeven) { totalE = totalE + E7 }
         if (isGameEight) { totalE = totalE + E8 }
         if (isGameNine) { totalE = totalE + E9 }
         
        var rating: Double
        let kMult = totalP - totalE
         
        print (K * kMult)
        if (numGames < 4) { myBonusGameCount = 4}
        else { myBonusGameCount = numGames }
        
        bonus = (K*kMult)-(14*(myBonusGameCount.squareRoot()))
        if (bonus < 0) { bonus = 0.0}
        if (numGames < 3) { bonus = 0.0}
        print (bonus)
         
    /*    var myExp=0.0, pvEst = 0.0, myEst=4000.0, myLow=0.0, myHigh=4000.0, fDiff=0.0
        var ratingDiff: Double
        let log10 = log(Double(10));
        let e = Darwin.M_E
        
        for n in gamesArray
        {
            myExp = myExp + (1.0/((pow(e, (log10*((n-myEst)/400.0))))+1.0))
        }
        
        if (numPrevious <= 8){
            while (abs(myEst - pvEst) > 0.1) {
                
                myExp = 0.0
                
                for n in gamesArray
                {
                    ratingDiff = myEst - n
                    if ( ratingDiff > 400 ){
                        myExp = myExp + 1.0
                    }
                    else if ( ratingDiff < -400 ){
                        myExp = myExp + 0.0
                    }
                    else{
                        myExp = myExp + 0.5 + (ratingDiff/800)
                    }
                }
            
            
                fDiff = myExp - totalP
                pvEst = myEst
                if ( fDiff > 0.0 )
                {
                    myHigh = myEst
                    myEst = ( myEst + myLow ) / 2.0
                }
                else
                {
                    myLow = myEst
                    myEst = ( myEst + myHigh ) / 2.0
                }
            }
            rating = ((numPrevious*pre) + (numGames * rating))
            rating = rating/(numPrevious + numGames)
        }
        else {
            if (pre < 2355) {
                numPrevious = 50.0 / (( 0.662 + (2569-pre)*(2569-pre)*0.000007390).squareRoot());
            }
            else{
                numPrevious = 50;
            }
            if ( numPrevious > numPre ) { numPrevious = numPre }
            K = 800.0 / (numPrevious + numGames)
            if (numGames < 4) { myBonusGameCount = 4}
            else { myBonusGameCount = numGames }
            bonus = K * ( totalP - myExp ) - (14 * (myBonusGameCount.squareRoot()))
            if (bonus < 0.0) { bonus = 0.0 }
            if (numGames < 3) { bonus = 0.0 }
            
            rating = pre + bonus + (K*(totalP-myExp))
        } */
        rating = pre + (K*kMult) + bonus
        rating = round(rating)
        if ((totalP > numGames))
            { newRatingLabel.text = "Invalid"
                performanceLabel.text = "Invalid" }
            
        else { newRatingLabel.text = String (format: "%0.0f", rating) }
     }
     
     func calculateE (preRating: Double, opponent: Double) -> Double {
         let place1: Double = -(preRating-opponent)/400.0
         let placeholder1 = pow(10.0, place1)
         let E: Double = Double(1/(placeholder1 + 1))
         
        // 1.0/(((pow(log10,(n-myEst))/400.0))+1.0)
        
         return E
     }
     
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
     }
     
     override func viewDidLoad() {
         super.viewDidLoad()
        
        print(pow(8, 3))
         // Do any additional setup after loading the view.
         
        // mainView.layer.cornerRadius = 10
             
         // add border to main view
         //mainView.layer.borderWidth = 1
         //mainView.layer.borderColor = UIColor.black.cgColor
         
        performanceLabel.layer.cornerRadius = 10
        newRatingLabel.layer.cornerRadius = 10
        performanceLabel.clipsToBounds = true
        newRatingLabel.clipsToBounds = true
        
         /* add light gray border to each game text field
         gameOne.layer.borderWidth = 2
         gameTwo.layer.borderWidth = 2
         gameThree.layer.borderWidth = 2
         gameFour.layer.borderWidth = 2
         gameFive.layer.borderWidth = 2
         gameSix.layer.borderWidth = 2
         gameSeven.layer.borderWidth = 2
         gameEight.layer.borderWidth = 2
         gameNine.layer.borderWidth = 2

         gameOne.layer.borderColor = UIColor.lightGray.cgColor
         gameTwo.layer.borderColor = UIColor.lightGray.cgColor
         gameThree.layer.borderColor = UIColor.lightGray.cgColor
         gameFour.layer.borderColor = UIColor.lightGray.cgColor
         gameFive.layer.borderColor = UIColor.lightGray.cgColor
         gameSix.layer.borderColor = UIColor.lightGray.cgColor
         gameSeven.layer.borderColor = UIColor.lightGray.cgColor
         gameEight.layer.borderColor = UIColor.lightGray.cgColor
         gameNine.layer.borderColor = UIColor.lightGray.cgColor */

         gameOne.delegate = self
         gameTwo.delegate = self
         gameThree.delegate = self
         gameFour.delegate = self
         gameFive.delegate = self
         gameSix.delegate = self
         gameSeven.delegate = self
         gameEight.delegate = self
         gameNine.delegate = self
         
         totalPoints.delegate = self
         preRating.delegate = self
         
     }
     
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
         
         gameOne.resignFirstResponder()
         gameTwo.resignFirstResponder()
         gameThree.resignFirstResponder()
         gameFour.resignFirstResponder()
         gameFive.resignFirstResponder()
         gameSix.resignFirstResponder()
         gameSeven.resignFirstResponder()
         gameEight.resignFirstResponder()
         gameNine.resignFirstResponder()
         
         preRating.resignFirstResponder()
         totalPoints.resignFirstResponder()
         
         return true
     }
     
    
}

